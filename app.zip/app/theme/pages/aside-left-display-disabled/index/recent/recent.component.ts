import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { DashBoardService } from '../../../../../_services/dash-board.service';
import { Data } from '../../../../../model/data';

@Component({
    selector: 'app-recent',
    templateUrl: "./recent.component.html",
    styleUrls: ['./recent.component.css'],
    encapsulation: ViewEncapsulation.None,
})
export class RecentComponent implements OnInit {
    recentMessages = [];
    constructor(private dashBoard: DashBoardService) { }
    ngOnInit() {
        this.getRecentData();
    }

    reload() {
        this.getRecentData();
    }

    getRecentData() {
        this.dashBoard.getDataRecent().subscribe((res: Data[]) => {
            this.recentMessages = res;
        });
    }
}
