import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Chart } from 'chart.js';
import { Data } from '../../../../../model/data';
import { DashBoardService } from '../../../../../_services/dash-board.service';

@Component({
    selector: 'app-monthly',
    templateUrl: "./monthly.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class MonthlyComponent implements OnInit {
    lineChart = [];
    data: Data[];
    date = [];
    open = [];
    error = [];
    completed = [];
    constructor(private dashBoard: DashBoardService) { }

    ngOnInit() {
        this.getMonthyData();
    }

    reload() {
        this.getMonthyData();
    }

    getMonthyData() {
        this.date = [];
        this.open = [];
        this.error = [];
        this.completed = [];
        this.lineChart = [];
        this.dashBoard.getDataMonth().subscribe((res: Data[]) => {
            res.forEach((y) => {
                this.date.push(y.Date);
                this.open.push(y.Open);
                this.error.push(y.Error);
                this.completed.push(y.Completed);
            });
            //console.log(this.fail);
            this.lineChart = new Chart('linecanvas', {
                type: 'line',
                data: {
                    //labels: ["1", "5", "10", "15", "20", "25", "30"],
                    labels: this.date,
                    datasets: [
                        {
                            backgroundColor: "rgb(54, 163, 247, 0.9)",
                            borderColor: "#36a3f7",
                            borderWidth: "2",
                            pointBorderColor: "#fff",
                            pointBorderWidth: "1",
                            strokeColor: "rgb(54, 163, 247, 0.9)",
                            pointColor: "rgb(54, 163, 247, 0.9)",
                            pointStrokeColor: "#fff",
                            data: this.open,
                            //data: ["10", "15", "20", "15", "20", "25", "30"],
                            label: 'Open'
                        },
                        {
                            backgroundColor: "rgb(244, 81, 108, 0.9)",
                            borderColor: "#f4516c",
                            borderWidth: "2",
                            pointBorderColor: "#fff",
                            pointBorderWidth: "1",
                            strokeColor: "rgb(244, 81, 108, 0.9)",
                            pointColor: "rgb(244, 81, 108, 0.9)",
                            pointStrokeColor: "#fff",
                            data: this.error,
                            //data: ["5", "8", "4", "15", "9", "2", "3"],
                            label: 'Error'
                        },
                        {
                            backgroundColor: "rgb(52, 191, 163, 0.9)",
                            borderColor: "#34bfa3",
                            borderWidth: "2",
                            pointBorderColor: "#fff",
                            pointBorderWidth: "1",
                            strokeColor: "rgb(52, 191, 163, 0.9)",
                            pointColor: "rgb(52, 191, 163, 0.9)",
                            pointStrokeColor: "#fff",
                            data: this.completed,
                            //data: ["13", "18", "14", "5", "19", "12", "13"],
                            label: 'Completed'
                        }
                    ]
                },
                options: {
                    legend: {
                        display: true,
                        borderColor: [
                            '#f38630',
                            '#e0e4cc',
                            '#69d2e7'

                        ],
                        position: 'bottom',
                        labels: {
                            fontColor: '#555',
                            usePointStyle: true,
                        }
                    },
                    scales: {
                        xAxes: [
                            {
                                display: true

                            }
                        ],
                        yAxes: [
                            {
                                display: true

                            }
                        ]
                    }
                }
            });
        });
    }
}
