import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Chart } from 'chart.js';
import { DashBoardService } from '../../../../../_services/dash-board.service';
import { Data } from '../../../../../model/data';

@Component({
    selector: 'app-yearly',
    templateUrl: "./yearly.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class YearlyComponent implements OnInit {
    month = [];
    open = [];
    error = [];
    completed = [];
    barChart = [];
    constructor(private dashBoard: DashBoardService) { }

    ngOnInit() {
        this.getYearData();
    }
    reload() {
        this.getYearData();
    }

    getYearData() {
        this.month = [];
        this.open = [];
        this.error = [];
        this.completed = [];
        this.barChart = [];
        this.dashBoard.getDataByYear().subscribe((res: Data[]) => {
            //console.log(res);
            res.forEach((y) => {
                this.month.push(y.Month);
                this.open.push(y.Open);
                this.error.push(y.Error);
                this.completed.push(y.Completed);
            });
            this.barChart = new Chart('barcanvas', {
                type: 'bar',
                data: {
                    labels: this.month,
                    datasets: [
                        {
                            backgroundColor: "rgb(54, 163, 247, 0.9)",
                            borderColor: "#36a3f7",
                            borderWidth: "2",
                            pointBorderColor: "#fff",
                            pointBorderWidth: "1",
                            strokeColor: "rgb(54, 163, 247, 0.9)",
                            pointColor: "rgb(54, 163, 247, 0.9)",
                            pointStrokeColor: "#fff",
                            data: this.open,
                            label: 'Open'
                        },
                        {
                            backgroundColor: "rgb(244, 81, 108, 0.9)",
                            borderColor: "#f4516c",
                            borderWidth: "2",
                            pointBorderColor: "#fff",
                            pointBorderWidth: "1",
                            strokeColor: "rgb(244, 81, 108, 0.9)",
                            pointColor: "rgb(244, 81, 108, 0.9)",
                            pointStrokeColor: "#fff",
                            data: this.error,
                            label: 'Error'
                        },
                        {
                            backgroundColor: "rgb(52, 191, 163, 0.9)",
                            borderColor: "#34bfa3",
                            borderWidth: "2",
                            pointBorderColor: "#fff",
                            pointBorderWidth: "1",
                            strokeColor: "rgb(52, 191, 163, 0.9)",
                            pointColor: "rgb(52, 191, 163, 0.9)",
                            pointStrokeColor: "#fff",
                            data: this.completed,
                            label: 'Completed'
                        }
                    ]

                },
                options: {
                    legend: {
                        display: true,
                        borderColor: [
                            '#f38630',
                            '#e0e4cc',
                            '#69d2e7'

                        ],
                        position: 'bottom',
                        labels: {
                            fontColor: '#555',

                        }
                    },
                    scales: {
                        xAxes: [
                            {
                                display: true
                            }
                        ],
                        yAxes: [
                            {
                                display: true,
                                ticks: {
                                    beginAtZero: true
                                }
                            }
                        ]
                    }
                }
            });
        });
    }

}
