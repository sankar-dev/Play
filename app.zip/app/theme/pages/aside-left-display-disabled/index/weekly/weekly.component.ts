import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { DashBoardService } from '../../../../../_services/dash-board.service';
import { Data } from '../../../../../model/data';
import { Chart } from 'chart.js';


@Component({
    selector: 'app-weekly',
    templateUrl: "./weekly.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class WeeklyComponent implements OnInit {
    status = [];
    total = [];
    weeklyChart = [];
    open: any;
    error: any;
    completed: any;
    constructor(private dashBoard: DashBoardService) { }

    ngOnInit() {
        this.getWeeklyCounts();
    }

    reload() {
        this.getWeeklyCounts();
    }

    getWeeklyCounts() {
        this.status = [];
        this.total = [];
        this.weeklyChart = [];
        this.dashBoard.getDataByWeekly().subscribe((res: Data[]) => {
            //console.log(res);

            res.forEach((y) => {
                if (y.Status == 'Open') {
                    this.open = y.Total;
                    this.status.push('Open');
                    this.total.push(this.open);
                }
                if (y.Status == 'Error') {
                    this.error = y.Total;
                    this.status.push('Error');
                    this.total.push(this.error);
                }
                if (y.Status == 'Completed') {
                    this.completed = y.Total;
                    this.status.push('Completed');
                    this.total.push(this.completed);
                }


            });


            this.weeklyChart = new Chart('weekly_chart', {
                type: 'doughnut',
                data: {
                    labels: this.status,
                    datasets: [
                        {
                            data: this.total,
                            backgroundColor: [
                                'rgb(54, 163, 247)',
                                'rgb(244, 81, 108)',
                                'rgb(52, 191, 163)'
                            ],
                            borderColor: [
                                '#36a3f7',
                                '#f4516c',
                                '#34bfa3'
                            ],
                            fill: false
                        }
                    ]
                },
                options: {
                    legend: {
                        display: true,
                        borderColor: [
                            'rgba(102, 180, 219, 0.30)',
                            'rgba(247, 69, 72, 0.3)',
                            'rgba(38, 181, 55, 0.5)'

                        ],
                        position: 'bottom',
                        labels: {
                            fontColor: '#555',
                            usePointStyle: true,
                        }
                    },
                    scales: {
                        xAxes: [
                            {
                                display: false
                            }
                        ],

                        yAxes: [
                            {
                                display: false
                            }
                        ]
                    }/* ,
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    } */
                },

            });


        });
    }

}
