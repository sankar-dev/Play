import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { DashBoardService } from '../../../../../_services/dash-board.service';
import { Data } from '../../../../../model/data';

@Component({
    selector: 'app-daily',
    templateUrl: "./daily.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class DailyComponent implements OnInit {

    constructor(private dashBoard: DashBoardService) { }
    total: any;
    open: any;
    error: any;
    completed: any;
    openPercentage: any;
    errorPercentage: any;
    completedPercentage: any;

    ngOnInit() {
        this.getDailyCounts();
    }

    reload() {
        this.getDailyCounts();
    }

    getDailyCounts() {
        this.dashBoard.getDataDaily().subscribe((res: Data[]) => {
            console.log(res);

            res.forEach((y) => {
                this.total = y.Total;
                this.open = y.Open;
                this.error = y.Error;
                this.completed = y.Completed;
                this.openPercentage = (this.open / this.total) * 100;
                this.errorPercentage = (this.error / this.total) * 100;
                this.completedPercentage = (this.completed / this.total) * 100;
            });

        });
    }

}
