import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user.component';
import { LayoutModule } from '../../layouts/layout.module';
import { DefaultComponent } from '../default/default.component';
import { ListuserComponent } from './listuser/listuser.component';
import { EdituserComponent } from './edituser/edituser.component';
import { AdduserComponent } from './adduser/adduser.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatPaginatorModule, MatTableModule } from '@angular/material';

const routes: Routes = [
    {
        "path": "",
        "component": DefaultComponent,
        "children": [
            {
                "path": "",
                "component": UserComponent
            },
            {
                "path": "list-user",
                "component": ListuserComponent
            },
            {
                "path": "add-user",
                "component": AdduserComponent
            },
            {
                "path": "edit-user",
                "component": EdituserComponent
            }
        ]
    }
];
@NgModule({
    imports: [
        CommonModule, RouterModule.forChild(routes), LayoutModule,ReactiveFormsModule,
        FormsModule,MatPaginatorModule, MatTableModule
    ], exports: [
        RouterModule
    ], declarations: [
        UserComponent,
        ListuserComponent,
        EdituserComponent,
        AdduserComponent
    ]
})
export class UserModule {



}