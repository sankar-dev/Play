import { Injectable } from '@angular/core';
import { Data } from '../model/data';
import { HttpClient } from '@angular/common/http';

@Injectable()

export class DashBoardService {
    data: Data[];
    url_year = 'http://localhost:3000/api/messages?filter=year&year=2019';
    url_month = 'http://localhost:3000/api/messages?filter=month&year=2019&month=01';
    url_weekly = 'http://localhost:3000/api/messages?filter=weekly';
    url_recent = 'http://localhost:3000/api/messages?filter=recent';
    url_overview = 'http://localhost:3000/api/messages?filter=overview';
    url_daily = 'http://localhost:3000/api/messages?filter=daily';
    constructor(private http: HttpClient) { }
    /* getData(){
      return this.http.get(this.url);
    } */
    getDataMonth() {
        return this.http.get(this.url_month);
    }

    getDataByYear() {
        return this.http.get(this.url_year);
    }

    getDataByWeekly() {
        return this.http.get(this.url_weekly);
    }

    getDataRecent() {
        return this.http.get(this.url_recent);
    }

    getDataOverview() {
        return this.http.get(this.url_overview);
    }

    getDataDaily() {
        return this.http.get(this.url_daily);
    }
}
