export interface Data {
    Status: String;
    Total: Number;
    price: Number;
    Month: String;
    Open: Number;
    Error: Number;
    Completed: Number;
    message_status: String;
    from: String;
    to: String;
    Date: String;

}
